# Build HE30 Pro v0.28


The source archive includes the pinned native USB donor, factory defaults and verification scripts. Extract it and use xPack RISC-V GCC 14.2.0.

```powershell
python build.py --toolchain <toolchain-directory> --base donor-v0.3.bin --output build --input-budget --factory-defaults v026-defaults.json
$env:HE30_BUILD_DIR = (Resolve-Path build).Path
python verify_input_controls.py
python verify_gamepad_clock.py
python verify_gamepad.py
python verify.py
python verify_v026.py
python verify_nkro.py
python verify_fn_adc.py
python verify_settings.py
Remove-Item Env:HE30_BUILD_DIR
```
