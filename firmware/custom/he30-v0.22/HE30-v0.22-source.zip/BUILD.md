# HE30 v0.22 source build

Use Windows and xPack RISC-V GCC 14.2.0.

```powershell
python build.py --toolchain <toolchain-directory> --base donor-v0.3.bin --output build --fn-rgb
$env:HE30_BUILD_DIR = (Resolve-Path build).Path
python verify.py
python verify_fn_adc.py
python verify_settings.py
python verify_nkro.py
python verify_gamepad.py
```

The pinned donor contains the inherited USB startup and OEM recovery code. C and assembly source is provided for all of the custom code compiled in v0.22. The build script lists and checks each binary change to the donor.
