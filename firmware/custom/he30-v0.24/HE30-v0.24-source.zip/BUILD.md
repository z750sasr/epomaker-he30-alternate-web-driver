# HE30 Pro v0.24

Use Windows and xPack RISC-V GCC 14.2.0.

```powershell
python build.py --toolchain <toolchain-directory> --base donor-v0.3.bin --output build --calibration-qol
$env:HE30_BUILD_DIR = (Resolve-Path build).Path
python verify.py
python verify_fn_adc.py
python verify_settings.py
python verify_nkro.py
python verify_gamepad.py
```

The donor supplies inherited USB startup and OEM recovery code. The source archive covers all custom code and the build verifies the donor hash and modified addresses.
